poissonmix_varsel <-
function(X, jchosen = NULL, Gvec = 1:10)
{
  if (is.data.frame(X)) {X <- as.matrix(X)}
  if (is.null(jchosen)) {jchosen <- poissonmix_screen(X = X, Gvec = Gvec, threshold = 0)$jchosen}
  N <- nrow(X)
  P <- ncol(X)
  criterion <- TRUE
  iter <- 1
  
  list_jchosen=list(jchosen)
  
  print(paste("Initial Selected Variables: ", paste(jchosen, sep="," , collapse=","), sep=""))
  while (criterion)
  {
    print(paste("Iteration: ", iter, sep = ""))
    
    if (length(jchosen) < P)
    {
      # Forward
      fitpoissonNG <- poissonmix_all(X[ ,jchosen], Gvec = Gvec)
      BICdiff <- rep(-Inf, P)
      for (j in (1:P)[-jchosen])
      {
        fitpoissonG <- poissonmix_all(X[ ,c(jchosen, j)], Gvec = Gvec)
        
        y <- X[ ,j]
        Xregr <- X[ ,jchosen]
        datregr <- data.frame(y, Xregr)
        fitglm <- glm(y ~ ., family = poisson(link = "log"), data = datregr)
        fit1 <- glm(y ~ 1, family = poisson(link = "log"), data = datregr)
        modelscope <- list(lower = formula(fit1), upper = formula(fitglm))
        fitglmf <- step(fit1 , scope = modelscope, k = log(N), trace = 0, direction = "both")
        fitglmb <- step(fitglm, scope = modelscope, k = log(N), trace = 0, direction = "both")
        if (BIC(fitglmf) < BIC(fitglmb)) {fitglms <- fitglmf} else {fitglms <- fitglmb}
        
        predglms <- predict(fitglms, type = "response")
        BICglms <- 2 * sum(dpois(y, predglms, log = TRUE)) - log(N) * length(coef(fitglms))
        BICdiff[j] <- fitpoissonG$bestfit$BIC - (fitpoissonNG$bestfit$BIC + BICglms)
      }
      if (max(BICdiff) > 0)
      {
        j <- which.max(BICdiff)
        print(paste("Add Variable:", j, " BIC Difference:", round(max(BICdiff), 1)))
        jchosen <- c(jchosen, j)
        accept_forward <- TRUE
        
      } else {
        j <- which.max(BICdiff)
        print(paste("Add Variable: NONE", j, "BIC Difference:", round(max(BICdiff), 1)))
        accept_forward <- FALSE
      }
    } else {
      print("Add Variable: NONE  All variables in the model")
      accept_forward <- FALSE
    }
    
    # Backward
    if (length(jchosen) > 1)
    {
      if (length(jchosen) < P)
      {
        jremove <- setdiff(1:P,jchosen)
        fitpoissonG <- poissonmix_all(X[, -jremove], Gvec = Gvec)
        jrange <- (1:P)[-jremove]
      } else
      {
        jremove <- NULL
        fitpoissonG <- poissonmix_all(X, Gvec = Gvec)
        jrange <- (1:P)
      }
      BICdiff <- rep(-Inf, P)
      for (j in jrange)
      {
        fitpoissonNG <- poissonmix_all(X[ ,-c(jremove, j)], Gvec = Gvec)
        
        y <- X[ ,j]
        Xregr <- X[ ,-c(j, jremove)]
        datregr <- data.frame(y, Xregr)
        fitglm <- glm(y ~ ., family = poisson(link = "log"), data = datregr)
        fit1 <- glm(y ~ 1, family = poisson(link = "log"), data = datregr)
        modelscope <- list(lower = formula(fit1), upper = formula(fitglm))
        fitglmf <- step(fit1, scope = modelscope, k = log(N), trace = 0, direction = "both")
        fitglmb <- step(fitglm, scope = modelscope, k = log(N), trace = 0, direction = "both")
        if (BIC(fitglmf) < BIC(fitglmb)) {fitglms <- fitglmf} else {fitglms <- fitglmb}
        
        predglms <- predict(fitglms, type = "response")
        BICglms <- 2 * sum(dpois(y, predglms, log = TRUE)) - log(N) * length(coef(fitglms))
        BICdiff[j] <- (fitpoissonNG$bestfit$BIC + BICglms) - fitpoissonG$bestfit$BIC 
      }
      if (max(BICdiff) > 0)
      {
        j <- which.max(BICdiff)
        print(paste("Remove Variable:", j, " BIC Difference:", round(max(BICdiff), 1)))
        jchosen <- setdiff(jchosen, j)
        accept_backward <- TRUE
      } else {
        j <- which.max(BICdiff)
        print(paste("Remove Variable: NONE", j, "BIC Difference:", round(max(BICdiff), 1)))
        accept_backward <- FALSE
      }
    } else {
      print("Remove Variable: NONE. Only one variable in the model.")
      accept_backward <- FALSE
    }
    criterion <- (accept_forward) | (accept_backward)
    iter <- iter + 1
    print(paste("Current Selected Variables: ", paste(jchosen, sep="," , collapse=","), sep=""))
  
    # test for infinite loop
    if (criterion){
      isalready=FALSE
      for (i in 1:length(list_jchosen)) isalready=isalready+sum(identical(jchosen,list_jchosen[[i]]))
      if (isalready){
        criterion = FALSE;
        print("Stop due to infinite loop")
      } else {
        list_jchosen[[length(list_jchosen)+1]]=jchosen
      } 
    }
  }
  
  jchosen <- sort(jchosen)
  bestfit <- poissonmix_all(X[,jchosen], Gvec = Gvec)$bestfit
  return(list(jchosen = jchosen, bestfit = bestfit))
}
