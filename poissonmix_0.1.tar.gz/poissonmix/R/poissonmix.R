poissonmix <-
function(X, G = 3, trace = FALSE)
{
  if (is.vector(X))
  {
    X <- matrix(X, length(X), 1)
  }
  N <- nrow(X)
  P <- ncol(X)

  # Cluster the data using k-means
  # Initial parameter "guesses" based on k-means results
  
  fit0 <- kmeans(X, centers = G, nstart = 50, iter.max = 50)
  tau <- table(fit0$cl) / N
  lambda <- fit0$centers

  #fit0 <- Mclust(X, G = G, prior = priorControl(), verbose = FALSE)
  #tau <- fit0$parameters$pro
  #lambda <- fit0$parameters$mean
  
  # Controls for EM Algorithm
  crit <- TRUE
  logL0 <- -Inf
  eps <- 10 ^ (-3)
  
  while (crit)
  {
    # E-step
    W <- matrix(NA, N, G)
    lW <- matrix(NA, N, G)
    lWa <- lW
    for (g in 1:G)
    {
      if (P > 1)
      {
        Lambda <- matrix(lambda[g, ], N, P, byrow = TRUE)
        lW[, g] <- log(tau[g]) + apply(dpois(X, Lambda, log = TRUE), 1, sum)
        #lWa[, g] <- log(tau[g]) + apply(apply(X, 1, dpois, lambda[g, ], log = TRUE), 2, sum)
      } else {
        #W[ ,g] <- tau[g] * dpois(X, lambda[g, ])
        lW[ ,g] <- log(tau[g]) + dpois(X, lambda[g, ], log = TRUE)
      }
    }
    lWmax <- apply(lW, 1, max)
    W <- exp(lW-lWmax)
    Wsum <- apply(W, 1, sum)
    Z <- W / Wsum
    
    # Compute log-likelihood
    #logL <- sum(log(Wsum))
    logL <- sum(lWmax) + sum(log(Wsum))
    if (trace) 
    {
      print(data.frame(G, logL))
    }
    # M-step
    Ng <- apply(Z, 2, sum)
    tau <- Ng / N
    lambda <- (t(Z) %*% X) / Ng
    
    # Check convergence
    crit <- (logL - logL0 > eps)
    logL0 <- logL	
  }
  
  BIC <- 2 * logL - log(N) * ((G - 1) + G * P)
  
  l <- map(Z)
  
  res <- list(Z = Z, classification = l, tau = tau, lambda = lambda, G = G, BIC = BIC, logL = logL)
  return(res)
}
