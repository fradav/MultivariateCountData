poissonmix_all <-
function(X, Gvec = 1:10, trace = FALSE)
{
  bestfit <- list()
  Gmax <- max(Gvec)
  BICvec <-rep(NA, length = Gmax)
  BICmax <- -Inf
  names(BICvec) <- 1:Gmax
  for (g in Gvec)
  {
    fit <- poissonmix(X, G = g, trace = trace)
    BICvec[g] <- fit$BIC
    if (fit$BIC > BICmax)
    {
      bestfit <- fit
      BICmax <- fit$BIC
    }
  }
  return(list(bestfit = bestfit, BIC = BICvec[Gvec]))
}
