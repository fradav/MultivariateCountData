poissonmix_screen <-
function(X, Gvec = 1:10, threshold = 0)
{
  P <- ncol(X)
  Gmax <- max(Gvec)
  BICmat <- matrix(NA, Gmax, P)
  for (j in 1:P)
  {
    Gtry <- min(length(table(X[, j])), Gmax)
    fit <- poissonmix_all(X[, j], Gvec = Gvec[Gvec <= Gtry])
    BICmat[Gvec[Gvec <= Gtry], j] <- fit$BIC
  }
  BICdiff <- apply(BICmat, 2, max, na.rm = TRUE) - BICmat[1, ]
  Gvec <- apply(BICmat, 2, which.max)
  jchosen <-  (1:P)[BICdiff > threshold]
  list(jchosen = jchosen, BICdiff = BICdiff, BICmat = BICmat)
}
